package sth.core;

public enum PersonType {
	EMPLOYEE, TEACHER, STUDENT
}